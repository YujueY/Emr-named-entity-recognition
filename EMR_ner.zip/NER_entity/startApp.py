# -*- coding: utf-8 -*-
import os
import threading
import requests
import logging
import time

from docx import Document

from Usage import label_color

logging.info('这是 loggging info message')
logging.debug('这是 loggging debug message')
logging.warning('这是 loggging a warning message')
logging.error('这是 an loggging error message')
logging.critical('这是 loggging critical message')

status = "idle"
file_path = ""
out_path = ""
responseUrl = ""
payload = ""


def processOutput(fileJson):
    global status
    status = "busy"
    payload = {}
    payload["uId"] = fileJson["uId"]
    outputDir = fileJson["outputDir"]
    dataJson = fileJson['requestInfo'][0]["nodeList"][0]
    exportDir = fileJson["exportChannel"][0]
    new_exportDir = exportDir["exportDir"]
    if not os.path.exists(outputDir + new_exportDir):
        os.makedirs(outputDir+ new_exportDir)
    exportDest = exportDir["exportDest"]
    outpath = (outputDir + new_exportDir + "/" + exportDest + ".docx")
    responseUrl = fileJson['responseUrl']
    return dataJson, outpath, responseUrl, payload


def branch(json_data):
    global status
    global file_path
    global out_path
    global responseUrl
    global payload
    dataJson, outpath, responseUrl, payload = processOutput(json_data)
    file_path = processOutput(json_data)[0]
    out_path = processOutput(json_data)[1]
    label_color(file_path, out_path)
    status = 'idle'
    dic1 = {"status": "success", "result": []}
    payload.update(dic1)
    requests.post(responseUrl, data=payload)
    # print("支线输出成功")


def init():
    pass


def infer(json_data):
    global status
    if status == "idle":
        aa = threading.Thread(target=branch, args=(json_data,))
        aa.start()
        # print("主线输出成功")
        return {"status": "success", "result": []}


def model_status():
    return status


# json_datas = {
#     "uId": "20191219164203_1576744923728882931_C657261096473726976",
#     "responseUrl": "http://127.0.0.1:9002/pipeline/export/callback",
#     "outputDir": "F:\Pycharm\HMM1.0\\NER_entity",
#     "exportChannel": [{
#         "exportDir": "ner",
#         "exportDest": "电子病历输出.docx"
#     }],
#     "requestInfo": [{
#         "nodeList": ["F:\Pycharm\HMM1.0\\NER_entity\\text_data.docx"]
#     }]
# }
# infer(json_datas)
