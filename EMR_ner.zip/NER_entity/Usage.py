# -*- coding: utf-8 -*-
import re
from utils import load_model
from data import build_corpus
import docx
from docx.shared import RGBColor
from docx import Document
import time

list_word = []
hmm_pred = []
m = []

docx = Document()
p = docx.add_paragraph()
run = p.add_run('S：单字实体, 颜色青色' + '\n')
p.add_run('BODY：身体部位，颜色棕色' + '\n')
p.add_run('CHECK：医学检查，颜色蓝色' + '\n')
p.add_run('DISEASE：疾病实体，颜色红色' + '\n')
p.add_run('SIGN：疾病症状，颜色紫色' + '\n')
p.add_run('TREATMENT：治疗方式，颜色绿色' + '\n' + '\n' + '\n')
HMM_MODEL_PATH = './ckpts/hmm.pkl'
train_word_lists, train_tag_lists, word2id, tag2id = build_corpus("train1.1")


def label_color(filepath, outpath):
    # 输入文本标签预测
    global list_word, tag
    global hmm_pred

    # REMOVE_O = False  # 在评估的时候是否去除O标记
    print("读取数据...")
    # 读入docx类型
    file = Document(filepath)
    raw_data = []
    for line in file.paragraphs:
        line = line.text
        line = re.sub('[\t\n\u3000]', '', line)
        raw_data.append(line)
        # print(line)
    # 读入txt类型
    # with open('text_data.txt', 'r', encoding='utf-8') as f:
    #     raw_data = []
    #     for line in f.readlines():
    #         line = re.sub('[\t\n\u3000]', '', line)
    #         raw_data.append(line)
    # f.close()
    raw_data = str(raw_data)
    sentence = re.split(r'。', raw_data)
    sentences = []
    for m in list(sentence):
        if m != '':
            sentences.append(m)
    length = len(sentences)
    print('数据读取划分成功...')
    a = 0
    while a < length:
        # 去掉为空的字符
        data = re.split(r'[\\W]*', sentences[a])
        # [\u4e00-\u9fa5]中文范围
        res = re.compile(r"([\u4e00-\u9fa5])")
        str_list = []
        for i in data:
            if res.split(i) == None:
                str_list.append(str)
            else:
                ret = res.split(i)
                for ch in ret:
                    str_list.append(ch)

        list_word = [[w for w in str_list if len(w.strip()) > 0]]
        list_word = list(list_word)
        hmm_model = load_model(HMM_MODEL_PATH)
        hmm_pred = hmm_model.test(list_word, word2id, tag2id)
        list_word = list_word[0]
        hmm_pred = hmm_pred[0]

        result_word = get_valid_nertag(list_word, hmm_pred)

        result_all = []
        all_word = []
        for (word, tag) in result_word:
            result = ("".join(word), tag)
            old_word = ["".join(word)]
            for m in old_word:
                all_word.append(m)
            for j in result:
                result_all.append(j)
                # 关键字体变色
        digui(sentences[a])
        # 输出为单个字加标签
        # with open('result_raw.txt', 'w', encoding='utf-8') as ff:
        #     for i in list(result_words):
        #         ff.write(str(i) + '\n')
        # 输出为词加标签
        p.add_run('\n' + 'S：')
        for (word, tag) in result_word:
            if tag == 'S':
                p.add_run(str("".join(word)) + '，')
            else:
                p.add_run('')
        p.add_run('\n')
        p.add_run('BODY：')
        for (word, tag) in result_word:
            if tag == 'BODY':
                p.add_run(str("".join(word)) + '，')
            else:
                p.add_run('')
        p.add_run('\n')
        p.add_run('CHECK：')
        for (word, tag) in result_word:
            if tag == 'CHECK':
                p.add_run(str("".join(word)) + '，')
            else:
                p.add_run('')
        p.add_run('\n')
        p.add_run('DISEASE：')
        for (word, tag) in result_word:
            if tag == 'DISEASE':
                p.add_run(str("".join(word)) + '，')
            else:
                p.add_run('')
        p.add_run('\n')
        p.add_run('SIGN：')
        for (word, tag) in result_word:
            if tag == 'SIGN':
                p.add_run(str("".join(word)) + '，')
            else:
                p.add_run('')
        p.add_run('\n')
        p.add_run('TREATMENT：')
        for (word, tag) in result_word:
            if tag == 'TREATMENT':
                p.add_run(str("".join(word)) + '，')
            else:
                p.add_run('')
        p.add_run('' + '\n' + '\n')
        docx.save(outpath)
        a += 1
        print('第%d句成功！' % a)


def digui(content):
    # print(content + '------------->')
    data = re.split(r'[\\W]*', content)
    # [\u4e00-\u9fa5]中文范围
    reo = re.compile(r"([\u4e00-\u9fa5])")
    str_list = []
    for i in data:
        if reo.split(i) == None:
            str_list.append(str)
        else:
            ret = reo.split(i)
            for ch in ret:
                str_list.append(ch)
    list_word1 = [[w for w in str_list if len(w.strip()) > 0]]
    list_word1 = list(list_word1)
    hmm_model = load_model(HMM_MODEL_PATH)
    hmm_pred1 = hmm_model.test(list_word1, word2id, tag2id)
    list_word1 = list_word1[0]
    hmm_pred1 = hmm_pred1[0]
    result_word = get_valid_nertag(list_word1, hmm_pred1)
    if result_word:
        for (word, tag) in result_word:
            if tag == 'S':
                if "".join(word) == '(' or '':
                    break
                else:
                    pt = r'({})'.format("".join(word))
                    res = re.split(pt, content)
                # 分割
                if len(res) > 1:
                    run = p.add_run(res[0])
                    run = p.add_run(res[1])  # 输入关键字
                    run.font.color.rgb = RGBColor(0, 255, 255)
                    # docx.save('result.docx')
                    new_content = ''.join(res[2:])
                    # print(new_content)
                    if new_content and new_content != ' ':
                        digui(new_content)
                        break
                    else:
                        break
            elif tag == 'BODY':
                if "".join(word) == '':
                    break
                else:
                    pt = r'({})'.format("".join(word))
                    res = re.split(pt, content)
                # 分割
                if len(res) > 1:
                    run = p.add_run(res[0])
                    run = p.add_run(res[1])  # 输入关键字
                    run.font.color.rgb = RGBColor(165, 42, 42)
                    # docx.save('result.docx')
                    new_content = ''.join(res[2:])
                    # print(new_content)
                    if new_content and new_content != ' ':
                        digui(new_content)
                        break
                    else:
                        break
            elif tag == 'CHECK':
                if "".join(word) == 'pg/mL' or '':
                    break
                else:
                    pt = r'({})'.format("".join(word))
                    res = re.split(pt, content)
                # 分割
                if len(res) > 1:
                    run = p.add_run(res[0])
                    run = p.add_run(res[1])  # 输入关键字
                    run.font.color.rgb = RGBColor(0, 0, 250)
                    # docx.save('result.docx')
                    new_content = ''.join(res[2:])
                    if new_content != '' and new_content != ' ':
                        digui(new_content)
                        break
                    else:
                        break

            elif tag == 'DISEASE':
                if "".join(word) == '':
                    break
                else:
                    pt = r'({})'.format("".join(word))
                    res = re.split(pt, content)
                # 分割
                if len(res) > 1:
                    run = p.add_run(res[0])
                    run = p.add_run(res[1])  # 输入关键字
                    run.font.color.rgb = RGBColor(250, 0, 0)
                    # docx.save('result.docx')
                    new_content = ''.join(res[2:])
                    # print(new_content)
                    if new_content and new_content != ' ':
                        digui(new_content)
                        break
                    else:
                        break

            elif tag == 'SIGN':
                if "".join(word) == '':
                    break
                else:
                    pt = r'({})'.format("".join(word))
                    res = re.split(pt, content)
                # 分割
                if len(res) > 1:
                    run = p.add_run(res[0])
                    run = p.add_run(res[1])  # 输入关键字
                    run.font.color.rgb = RGBColor(128, 0, 128)
                    # docx.save('result.docx')
                    new_content = ''.join(res[2:])
                    # print(new_content)
                    if new_content and new_content != ' ':
                        digui(new_content)
                        break
                    # elif new_content != ' ':
                    #     digui(new_content)
                    #     break
                    else:
                        break

            elif tag == 'TREATMENT':
                if "".join(word) == '':
                    break
                else:
                    pt = r'({})'.format("".join(word))
                    res = re.split(pt, content)
                # 分割
                if len(res) > 1:
                    run = p.add_run(res[0])
                    run = p.add_run(res[1])  # 输入关键字
                    run.font.color.rgb = RGBColor(0, 128, 0)
                    # docx.save('result.docx')
                    new_content = ''.join(res[2:])
                    # print(new_content)
                    if new_content and new_content != ' ':
                        digui(new_content)
                        break
                    else:
                        break
    else:
        # print('---------------')
        # print('end')
        p.add_run(content + '\n' + '\n')
        # docx.save('result.docx')


def get_valid_nertag(input_data, result_tags):
    # 对预测结果进行命名实体解析和提取
    result_words = []
    start, end = 0, 1  # 实体开始结束位置标识
    tag_label = "O"  # 实体类型标识
    for i, tag in enumerate(result_tags):
        if tag.startswith("B"):
            if tag_label != "O":  # 当前实体tag之前有其他实体
                result_words.append((input_data[start: end], tag_label))  # 获取实体
            tag_label = tag.split("-")[1]  # 获取当前实体类型
            start, end = i, i + 1  # 开始和结束位置变更
        elif tag.startswith("I"):
            temp_label = tag.split("-")[1]
            if temp_label == tag_label:  # 当前实体tag是之前实体的一部分
                end += 1  # 结束位置end扩展
        elif tag.startswith("E"):
            temp_label = tag.split("-")[1]
            if temp_label == tag_label:  # 当前实体tag是之前实体的一部分
                end += 1  # 结束位置end扩展
        elif tag == "O":
            if tag_label != "O":  # 当前位置非实体 但是之前有实体
                result_words.append((input_data[start: end], tag_label))  # 获取实体
                tag_label = "O"  # 实体类型置"O"
            start, end = i, i + 1  # 开始和结束位置变更
        elif tag == "S":
            result_words.append((input_data[start: end], 'S'))  # 获取实体
            start, end = i, i + 1  # 开始和结束位置变更
    if tag_label != "O":  # 最后结尾还有实体
        result_words.append((input_data[start: end], tag_label))  # 获取结尾的实体
    return result_words


# t1 = time.time()
# file_path = "text_data.docx"
# out_path = "result.docx"
# label_color(file_path, out_path)
# t2 = time.time()
# print(t2 - t1)
# print("成功输出数据到文档...")
